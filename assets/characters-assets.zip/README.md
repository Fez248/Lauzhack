# Character illustrations

The four guides of **This Is Tea [DCST]** (see [`docs/characters.md`](../../docs/characters.md)).
Each one is a hand-written SVG, so you can edit colours and shapes directly in the file.

| File | Character | Role | Palette |
|------|-----------|------|---------|
| [`cat.svg`](cat.svg) | Cat (she) | Personal security, zero-trust mindset | fur `#7D88BC`, shade `#5D679C`, light `#C3C9E6`, amber `#F2B23B` |
| [`turtle.svg`](turtle.svg) | Turtle (she) | Organisational / collective security | skin `#9DC47B` / `#79A55A`, shell `#C49359` / `#9A6C3C`, cream `#EADCB0` |
| [`dog.svg`](dog.svg) | Dog (he) | Free / open-source security tools | golden `#F2BE66` / `#D9A04A`, ears `#B97A3E`, cream `#FCF2DE`, teal `#3DA6A2` |
| [`spider.svg`](spider.svg) | Spider (he) | Phishing simulations, teaches by catching you | purple `#8562B5` / `#634490`, lilac `#B79BDB`, red `#E0394B` (only the eyes) |

## Design language

- **Light and friendly:** mid-to-light fills. Each character has one main colour, a darker
  shade of it and a lighter accent.
- **Coloured outlines:** each character is outlined in a very dark tone of its own palette
  (cat `#2F3361`, turtle `#3F3A22`, dog `#5A3518`, spider `#2E1C45`) instead of black.
  Stroke widths are 6–7 for silhouettes and 3–5 for inner lines. Joins and caps are round.
- **Organic shapes:** silhouettes are built from smooth Bézier curves, without circles or
  rectangles.
- **Detail on the body:** chest fluff (cat), scutes, skin spots and claws
  (turtle), a chest patch and a dotted bandana (dog), joint bands and an abdomen chevron
  (spider). The cat's body and tail and the dog's ears have no inner lines.
- **Simple faces:** round eyes (except the spider's) with a white sclera, a coloured iris, a pupil and one highlight,
  plus a nose and a one-line mouth. Expression comes from a single extra element:
  - Cat: amber slit pupils with slightly lowered lids (calm, in control).
  - Turtle: fully open eyes and a soft blush (kind).
  - Dog: open eyes and gentle brows (friendly, wise).
  - Spider: narrow trapezoid eyes with red irises and slit pupils, heavy slanted brows and a
    smirk (scary, scheming).
- **Flat vector:** solid fills only, no gradients or filters.
- **Canvas:** `viewBox="0 0 512 512"`, transparent background, with the character centred.
  Silhouettes are simple enough to stay readable at 64 px.

## File structure

Each file starts with a comment header (character, personality, palette) and is split into
named `<g id="…">` groups, drawn back to front, e.g. `tail` → `body` → `head` → `face` → `eyes`.

- To recolour a character, search and replace its hex values.
- Tails and spider legs are drawn as two strokes: a wide outline stroke underneath and a
  narrower coloured stroke on top. Change both when you edit them.
- To preview, open the file in a browser, or run `rsvg-convert -w 512 cat.svg -o cat.png`.

## Avatars

`avatars/<name>.svg` are round profile icons, one for each character. Each one crops the face
from the full illustration into a circle, puts a soft background in the character's own palette
behind it, and adds an outline ring. They are drawn for 32–256 px.

Each avatar contains a copy of its character's art, so after you edit a character, regenerate
its avatar (or copy the edited groups into the `character` group).

## Sprites

`sprites/` holds transparent PNG exports for the app:

| File | Size |
|------|------|
| `<name>-128.png`, `<name>-256.png`, `<name>-512.png` | Full character, square |
| `<name>-avatar-64.png`, `<name>-avatar-128.png`, `<name>-avatar-256.png` | Round avatar, square |
| `characters-sheet.png` | 2048×512, cat · turtle · dog · spider, 512 px each |
| `avatars-sheet.png` | 1024×256, cat · turtle · dog · spider, 256 px each |

To re-export a sprite after editing an SVG:

```sh
rsvg-convert -w 256 cat.svg -o sprites/cat-256.png
rsvg-convert -w 128 avatars/cat.svg -o sprites/cat-avatar-128.png
```
